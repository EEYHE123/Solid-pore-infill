%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     A triple porosity scheme for fluid/solid substitution: theory and experiment   %
%                                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%  %%%%%%%
% Version:  2022-08-11, 08-13, 2023-07-02, 2023-10-18
%%%%%%%%%%%%%%%%%%%%%%  %%%%%%% 
clc;   clear;
CC=colormap(jet(6));         % Color, open a figure
Fontsize=13;  
Fontsize1=13;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% for solid infill

filename='Ds-1-shibawan';
f_measure=xlsread(filename,1,'A3:A39'); 

  % ------------- Dry -----------------------------------------------------
  load('./Data/E_dry.mat');        % Young's modulus
  load('./Data/QE_dry.mat');       % Young's attenuation
  load('./Data/pos_dry.mat');      % Poisson's ratio
  
  E1_rbw_dry = E_dry_sm(:,1);    % 1 MPa
  E5_rbw_dry = E_dry_sm(:,2);    % 5 MPa applied
  E10_rbw_dry = E_dry_sm(:,3);   % 10 MPa applied
  E15_rbw_dry = E_dry_sm(:,4);   % 15 MPa
  E20_rbw_dry = E_dry_sm(:,5);   % 20 MPa
  
  QE1_rbw_dry = QE2_dry_sm1(:,1);    % 1 MPa
  QE5_rbw_dry = QE2_dry_sm1(:,2);    % 5 MPa applied
  QE10_rbw_dry = QE2_dry_sm1(:,3);   % 10 MPa applied
  QE15_rbw_dry = QE2_dry_sm1(:,4);   % 15 MPa
  QE20_rbw_dry = QE2_dry_sm1(:,5);   % 20 MPa
  
  v1_rbw_dry  = v_sm(:,1);       % 1 MPa
  v5_rbw_dry  = v_sm(:,2);       % 5 MPa applied
  v10_rbw_dry = v_sm(:,3);       % 10 MPa applied
  v15_rbw_dry = v_sm(:,4);       % 15 MPa
  v20_rbw_dry = v_sm(:,5);       % 20 MPa
  
  % --------- solid -------------------------------------------------------
  load('./Data/E_23.mat');
  load('./Data/QE_23.mat');
  load('./Data/pos_23.mat');      % Poisson's ratio
  
  E1_23rbw = E_rbw_23(:,1);    % 1 MPa
  E5_23rbw = E_rbw_23(:,2);    % 5 MPa applied
  E10_23rbw = E_rbw_23(:,3);   % 10 MPa applied
  E15_23rbw = E_rbw_23(:,4);   % 15 MPa
  E20_23rbw = E_rbw_23(:,5);   % 20 MPa
  
  QE1_23rbw = QE_rbw_23(:,1);    % 1 MPa
  QE5_23rbw = QE_rbw_23(:,2);    % 5 MPa applied
  QE10_23rbw = QE_rbw_23(:,3);   % 10 MPa applied
  QE15_23rbw = QE_rbw_23(:,4);   % 15 MPa
  QE20_23rbw = QE_rbw_23(:,5);   % 20 MPa

  v1_rbw_23  = v_sm1(:,1);       % 1 MPa
  v5_rbw_23  = v_sm1(:,2);       % 5 MPa applied
  v10_rbw_23 = v_sm1(:,3);       % 10 MPa applied
  v15_rbw_23 = v_sm1(:,4);       % 15 MPa
  v20_rbw_23 = v_sm1(:,5);       % 20 MPa
  
  % -------------- fluid --------------------------------------------------
  load('./Data/E_30.mat');
  load('./Data/QE_30.mat');
  load('./Data/pos_30.mat');      % Poisson's ratio
  
  E1_30rbw = E_rbw_30(:,1);    % 1 MPa
  E5_30rbw = E_rbw_30(:,2);    % 5 MPa applied
  E10_30rbw = E_rbw_30(:,3);   % 10 MPa applied
  E15_30rbw = E_rbw_30(:,4);   % 15 MPa
  E20_30rbw = E_rbw_30(:,5);   % 20 MPa
  
  QE1_30rbw = QE_rbw_30(:,1);    % 1 MPa
  QE5_30rbw = QE_rbw_30(:,2);    % 5 MPa applied
  QE10_30rbw = QE_rbw_30(:,3);   % 10 MPa applied
  QE15_30rbw = QE_rbw_30(:,4);   % 15 MPa
  QE20_30rbw = QE_rbw_30(:,5);   % 20 MPa
  
  v1_rbw_30  = v_sm30(:,1);       % 1 MPa
  v5_rbw_30  = v_sm30(:,2);       % 5 MPa applied
  v10_rbw_30 = v_sm30(:,3);       % 10 MPa applied
  v15_rbw_30 = v_sm30(:,4);       % 15 MPa
  v20_rbw_30 = v_sm30(:,5);       % 20 MPa  
%%%%=========================================================================

K_dry_lab=xlsread(filename,7,'C83:H83'); 
u_dry_lab=xlsread(filename,7,'C84:H84'); 

K_g = 35.6e9;
u_g = 36.2e9;
rho_s=2638;
por=0.201;
perm=272.1e-15;         

P_lab=[5 10 20 30 40 50].*1e-3;              %%% pressure  Lab；   
P_compute= P_lab(1):(1*1e-4):P_lab(end);       %%%pressure 

P5_ind = 1;          % Pressure, MPa
%-----------------------------------------

K_f_solid=3.87;
rho_solid=785;
u_f_solid=1.46;
visco_solid=1*10^4;

ff = 10.^(-2:0.057:16);   % Frequency

visco_10=5*10^(-3);
WR0=0.94*10^(-3); 
visco_2=1*10^(-5);   % 15*10^(-5);   % Viscosity of gas


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[v_HS_down,v_HS_up,v_SM,v_CS_5,v_model_5,E_HS_down,E_HS_up,E_SM,E_CS_5,E_model_5,Freqence,fre]...
    =f1 (K_g,u_g,rho_s,por,perm,P_lab,K_dry_lab,u_dry_lab,P_compute,P5_ind,K_f_solid,rho_solid,u_f_solid,visco_solid,ff,visco_10,WR0,visco_2);
  
  load ./E_model_fluid_5.mat;
  load ./v_model_fluid_5.mat;
  load ./Freq.mat;
 
  % -----------------------------------------------------------------------
  %%% GJI applied, v
%   Figure 12(c)
  scrsz = get(0,'ScreenSize');      %%  5 MPa
  figure('Position',[1 scrsz(4) scrsz(4)*0.55 scrsz(4)*0.36]);
      h0=semilogx(f_measure(1:2:36),v5_rbw_dry(1:2:end),'ok', 'linewidth',1);  hold on   % Dry
      h1=semilogx(f_measure(1:2:36),v5_rbw_23(1:2:end),'dk', 'linewidth',1);     % Solid
      h2=semilogx(f_measure(1:2:36),v5_rbw_30(1:2:end),'sk','linewidth',1);      % Fluid
      h3=plot([1e-2,1e+6],[v_HS_down,v_HS_down],'--k','linewidth',1.);  % HS+
      h4=plot([1e-2,1e+6],[v_HS_up,v_HS_up],'-.k','linewidth',1.);    % HS-
      h5=plot([1e-2,1e+6],[v_SM(1),v_SM(1)],'--b','linewidth',1.);   % SM
      h6=semilogx(Freqence,v_CS_5,'-g',   'linewidth',1.);                  % CS  
      h7=semilogx(fre,v_model_5,'-r','linewidth',1.);                    % TPA: triple pore      
      h8=semilogx(Freq,v_model_fluid_5,'-c','linewidth',1.);            % TPA: triple pore  
      
      set(gca,'xtick',[10^-2,10^-1,1,10,10^2,10^3,10^4,10^5,10^6],'Fontsize',Fontsize1);
      set(gca,'ytick',[0.1,0.2,0.3,0.4],'Fontsize',Fontsize1);
      xlabel('Frequency (Hz)','Fontsize',Fontsize1);
      ylabel('Poisson'' ratio {\it\nu}','Fontsize',Fontsize1); 
      xlim([10^-1 10^5]);      ylim([0.05 0.3]);
      box on;   grid on;   grid minor;      
      hh1=legend('Dry','Solid','Liquid','HS upper','HS lower','SM Model','CS Model','TPA (solid)','TPA (fliud)');  % ,'Liquid','TPR (liquid)','Gassman');
      set(hh1 ,'FontName','Times New Roman','Fontsize',Fontsize1);
  % -----------------------------------------------------------------------
  
  % -----------------------------------------------------------------------
  %%% GJI applied, E
%   Figure 12(a)
  scrsz = get(0,'ScreenSize');      %%  5 MPa
  figure('Position',[1 scrsz(4) scrsz(4)*0.55 scrsz(4)*0.36]);
      h0=semilogx(f_measure(1:2:36),E5_rbw_dry(1:2:end),'ok', 'linewidth',1);  hold on   % Dry
      h1=semilogx(f_measure(1:2:36),E5_23rbw(1:2:end),'dk', 'linewidth',1);     % Solid
      h2=semilogx(f_measure(1:2:36),E5_30rbw(1:2:end),'sk','linewidth',1);      % Fluid
      h3=plot([1e-2,1e+6],[E_HS_up,E_HS_up],'--k','linewidth',1.);           % HS+
      h4=plot([1e-2,1e+6],[E_HS_down,E_HS_down],'-.k','linewidth',1.);     % HS-
      h5=plot([1e-2,1e+6],[E_SM(1),E_SM(1)],'--b','linewidth',1.);              % SM
      h6=semilogx(Freqence, E_CS_5,'-g',  'linewidth',1.);                   % CS  
      h7=semilogx(fre,E_model_5,'-r','linewidth',1.);                 % TPA: triple pore 
      h8=semilogx(Freq,E_model_fluid_5,'-c','linewidth',1.);         % TPA: triple pore  
      
      set(gca,'xtick',[10^-2,10^-1,1,10,10^2,10^3,10^4,10^5,10^6],'Fontsize',Fontsize1);
      set(gca,'ytick',[10,20,30,40,50],'Fontsize',Fontsize1);
      xlabel('Frequency (Hz)','Fontsize',Fontsize1);
      ylabel('Young''s modulus {\itE} (GPa)','Fontsize',Fontsize1); 
      xlim([10^-1 10^5]);      ylim([8 50]);
      box on;   grid on;   grid minor;      
      hh1=legend('Dry (data)','Solid (data)','Liquid (data)','HS upper','HS lower','SM (solid)','CS (solid)','TPA (solid)','TPA (fliud)');  % ,'Liquid','TPR (liquid)','Gassman');
      set(hh1 ,'FontName','Times New Roman','Fontsize',Fontsize1);
  % -------------------------------------------------
 %%% =========================================================================  
 