function [v_HS_down,v_HS_up,v_SM,v_CS_5,v_model_5,E_HS_down,E_HS_up,E_SM,E_CS_5,E_model_5,Freqence,fre]=f1 (K_g,u_g,rho_s,por,perm,P_lab,K_dry_lab,u_dry_lab,P_compute,P5_ind,K_f_solid,rho_solid,u_f_solid,visco_solid,ff,visco_10,WR0,visco_2)
 K_g=K_g/10^9-15.6;   u_g=u_g/10^9-26.2;  fai=0.2356;   rho111=rho_s;  por11=por; k=perm;  omega=2*pi*ff;          
    visco_1=visco_10;
    rho_fl=1040;
    Kf_1=2.25*10^9;               % solid bulk modulus, zhengshibawan
    
    Kf_2=0.022*10^9;     % 0.081*10^9;
    Kg1=K_g*10^9;
    visco_wq=visco_solid;
    %%%%%%%%%%%%% eq(27)%%%%%%%%%%%%   
    fun27=@(A)A(1)*( 1+A(2)*(1/A(1)-1/K_g)*P_lab-A(3)*A(4)*exp(-A(3)*P_lab/A(1)) )-K_dry_lab;
    A_original= [ 0.3 1 319.5 0.1];   %%%%%   30 1 3195 0.1    0.3 1 319.5 0.1
    A_options= optimoptions(@lsqnonlin,'Algorithm','trust-region-reflective');
    A_compute= lsqnonlin(fun27,A_original,[],[],A_options);       % Four parmaters calculated
    K_dry_compute=A_compute(1)*( 1+A_compute(2)*(1/A_compute(1)-1/K_g)*P_compute-A_compute(3)*A_compute(4)*exp(-A_compute(3)*P_compute/A_compute(1)) );
    % K_bc=A_compute(1);
    K_bc=A_compute(1);  %%%%17.3
    theta_s=A_compute(2);
    theta_c=A_compute(3);
    fai_co=A_compute(4);

    fun28=@(B)B(1)*( 1+B(2)*(1/B(3)-1/K_g)*P_lab-B(4)*fai_co*exp(-theta_c*P_lab/B(3)) )-u_dry_lab;
    B_original= [10 3000 30 3000];   %%%%%  [30 0.001 0.1]     5000 1000 5000   20 3000 30 3000
    B_options = optimoptions(@lsqnonlin,'Algorithm','trust-region-reflective');
    B_compute= lsqnonlin(fun28,B_original,[],[],B_options);        % 3 parmate
    u_dry_compute=B_compute(1)*( 1+B_compute(2)*(1/B_compute(3)-1/K_g)*P_compute-B_compute(4)*fai_co*exp(-theta_c*P_compute/B_compute(3))   );
    u_bc=B_compute(1);
    theta_su=B_compute(2);
    K_bc1=B_compute(3);
    theta_cu=B_compute(4);
   % --------------------------------------------------------  
     
   %%%%%%%%%%%%%%% Aspect ratio distributions %%%%%%%%%%%%%%%%%%%%%%%%
   %%%%%%%%% Dry bulk modulus in the high-pressure-limit (when all compliant pore is closes), Gpa
   % -----------------------------------------------------
    sub=K_bc/K_g;
    syms phi_b1; 
    % phi_h=solve( (1-phi_h)^(3/(1-phi_h))-sub,'phi_h');   
    phi_b1 = solve( (1-phi_b1)^(3/(1-phi_b1))- sub );       % 2013_GJI-Kong_Effect_of_fracture (Eq36)
    solution_phi_h=double(phi_b1); 
    uh = u_g*(1-solution_phi_h)^(3/(1-solution_phi_h));     % 2013_GJI-Kong_Effect_of_fracture (Eq36), Gpa

    alpha_c = K_bc*(3*K_bc+4*uh)/(pi*uh*theta_c)/(3*K_bc+uh); uh=uh-0.58;   % Characteristic aspect ratio of compliant pore (Eq13):  
    % ==========================================================================
    
    % ===================================================================================
    %%% Calculating aspect ratio distribution of compliant pores
    ud_p1=u_dry_lab.*1e9;        % Dry bulk modulus, pa
    Kd_p1=K_dry_lab.*1e9;        % Dry shear modulus,
    po_ratio1 = (3*Kd_p1-2*ud_p1)./2/(3*Kd_p1+ud_p1);      % Poisson's ratio -- , page28

    p=P_lab*10^3*10^6;              % pa
    dp=0.2*10^6;
    pp=0:dp:p(end);
    
    %%% espilon, 
    e1=(Kd_p1(end)./Kd_p1-1)*9*(1-2*po_ratio1(end))/16/(1-po_ratio1(end)^2);                % Crack density from the bulk modulus, in Eq.(5) of 2015_CG
    e2=(ud_p1(end)./ud_p1-1)*45*(2-po_ratio1(end))/32/(1-po_ratio1(end))/(5-po_ratio1(end));  % Crack density from the shear modulus, in Eq.(5) of 2015_CG 
    
    z1=log(e1(1:end-1));         %%% Fitting the curves   
    z2=log(e2(1:end-1));

    c1=polyfit(p(1:end-1),z1,1);
    c2=polyfit(p(1:end-1),z2,1);

    ie1=exp(c1(1)*pp+c1(2));             %%% 
    ie2=exp(c2(1)*pp+c2(2));             % Fitting crack density, Eq.(7) of 2015_CG
    e10=exp(c1(2));
    e20=exp(c2(2));                      % 

    ie=(ie1+ie2)/2;                      %%% Mean of bulk and shear moduli
    
    iei=[0 ie(1:end-1)-ie(2:end)];       % 
    iek=[0 ie1(1:end-1)-ie1(2:end)];     % 
    ieu=[0 ie1(1:end-1)-ie1(2:end)];
    
    % -------------------------------------------------------------------------
    % Kd_p2 & ud_p2: the dry effective modulus; %%% 
    Kd_p2 = Kd_p1(end)./(1+16*(1-po_ratio1(end)^2)*ie1/9/(1-2*po_ratio1(end)));
    ud_p2 = ud_p1(end)./(1+32*(1-po_ratio1(end))*(5-po_ratio1(end))*ie2/45/(2-po_ratio1(end)));
    %%% Kd_p1(end):   K_stiff of Eq.(5) in 2015_CG
    %%% ud_p1(end):   The Poisson's ratio of the background matrix with only hard pores
    
    lamda_st2=Kd_p2-2*ud_p2/3;
    E2=3*Kd_p2.*ud_p2./(lamda_st2+ud_p2);                 % Not used!
    po_ratio2=0.5*lamda_st2./(lamda_st2+ud_p2);           % The Poisson's ratio

    lamda_st3=Kd_p1(end)-2*ud_p1(end)/3;                     % High-freq limit；%%% 
    E3=3*Kd_p1(end).*ud_p1(end)./(lamda_st3+ud_p1(end));     % Young's modulus
    po_ratio3=0.5*lamda_st3./(lamda_st3+ud_p1(end));

    alphai=4*(1-po_ratio3.^2).*pp./E3/pi;                    % Eq.(10) in 2015_CG, Eq.(12) in 2018_JGE
                                                             %%% 
    
    %%% Aspect ratio Variations with pressure: Eq.(13) in 2018_JGE
    alphap=zeros(length(pp),length(pp));         %% Aspect ratio,
    for ix=1:length(pp)
        if ( ix==1 )
            alphap(:,ix)=alphai-4*(1-po_ratio3^2)*0*dp/3/pi/Kd_p1(end)/(1-2*po_ratio3);        
        elseif ( ix>1 )
            alphap(:,ix)=alphap(:,ix-1)-4*(1-po_ratio3^2)*dp/3/pi/Kd_p1(end)/(1-2*po_ratio3);
        end
    end
    
    iei1=iei'*ones(1,length(pp));        % Crack density, 
    iek1=iek'*ones(1,length(pp));
    ieu1=ieu'*ones(1,length(pp));
    phyi=4*pi*alphap.*iei1/3;            % Line-15 in P-3394 in 2015_CG, Eq.(9) in 2018_JGE
                                         % Porosity of soft pores
    
    % -------------------------------------------------------------------------
    %%%%%% Remove the negative values                                    
    nn1=1;     nn2=1;              % 
    mn=zeros(1,length(pp));
    for np=1:length(pp)
          for n=1:length(pp)
              if phyi(n,np)<=1e-10
                  nn1=n+1;
              end
              if alphap(n,np)<=1e-10
                  nn2=n+1;
              end
          end
          if nn1>length(pp)&&nn2>length(pp)
              nn1=length(pp);
              nn2=length(pp);
          end
          mn(np)=max([nn1 nn2]);
    end 

    for np=1:length(pp)
    %     iei1(n,mn(np))=0;
        for n=mn(np):length(pp)                
            iei1(n,np)=iei1(n-1,np)+iei1(n,np);
            iek1(n,np)=iek1(n-1,np)+iek1(n,np);
            ieu1(n,np)=ieu1(n-1,np)+ieu1(n,np);
        end
    end
    % -------------------------------------------------------------------------
    
    phi_cp = fai_co*exp(-theta_c/K_bc*P_compute);      % Compliant porosity, Eq(11)
        %%%%  SC  ======================================================
           WR=WR0;           % WR=0.44*10^-9; 
            Sw=1;
            Sc0=WR*Sw*fai*phi_cp.^(-1);  % Eq6 -- 2018-
            Sc=Sc0;               %  Method 1
        %%%%%%%  ======================================================

    nc=26;
    for np=nc:length(pp)
        nn=mn(np);

        Kdry=Kd_p2(np);
        Kmf_alpha_c=0;
        if ( nn<=length(po_ratio2) )
            for ix=nn:length(po_ratio2)
                faic=phyi(ix,np);
                alpha=alphap(ix,np);

                Khi(ix)=Kd_p1(end)./(1+16*(1-po_ratio1(end)^2)*(ie1(np)-iek(ix))/9/(1-2*po_ratio1(end)));             %

                [Kmf_sp0,Kf_f0] = K_MF_2( Khi(ix),Kdry,omega,visco_1,visco_2,faic,alpha,Kg1,Kf_1,Kf_2,Sc(np-25) );    % Bulk modulus

                z=find(~isnan(Kmf_sp0));
                if ( z(end)<length(ff) )
                     Kmf_sp0(z(end)+1:end) = Kmf_sp0(z(end));    %%% 
                end
                Kmf_alpha_c = Kmf_alpha_c + Kmf_sp0;
            end
        end

        Kmf_alpha_c1(:,np-(nc-1)) = Kmf_alpha_c;
    end
    
    
    %%% -------------------------------------------------------------------
    %%%%% eq(36) %%%%%%%
    arf_c=K_bc*(3*K_bc+4*u_bc)/(pi*theta_c*u_bc*(3*K_bc+u_bc));


    %%%%%% 更高围压下的骨架模量 %%%%%%%%%  
    K_ufm_lab=K_bc*(1+theta_s*(1/K_bc-1/K_g)*P_lab);   %%%%%% eq(27) CPA 
    u_ufm_lab=u_bc*(1+theta_su*(1/K_bc-1/K_g)*P_lab);  %%%%%% eq(28) CPA 
    rho_qw=rho_solid;
    %%%%%%% K_bm
    fun32=@(D)D(1)*( 1-D(2)*D(3)*exp(-D(2)*P_lab/D(1)) )-K_ufm_lab;
    D_original=[100 3000 0.0001];    %%%%   [30 0.01 0.01];     100 3000 1
    D_options = optimoptions(@lsqnonlin,'Algorithm','trust-region-reflective');
    D_compute = lsqnonlin(fun32,D_original,[],[],D_options);        % 3 parmate
    K_ufm_compute=D_compute(1)*( 1-D_compute(2)*D_compute(3)*exp(-D_compute(2)*P_compute/D_compute(1)));
    K_bm=D_compute(1);
    theta_m=D_compute(2);
    fai_mo=abs(D_compute(3));

    %%%%% eq(33) %%%%%%
    fun33=@(E)E(1)*( 1-E(2)*fai_mo*exp(-theta_m*P_lab/K_bm) )-u_ufm_lab;
    E_original=[0.003 1];    %%%%   [30 0.01 0.01];   30 0.001
    E_options = optimoptions(@lsqnonlin,'Algorithm','trust-region-reflective');
    E_compute = lsqnonlin(fun33,E_original,[],[],E_options);        % 3 parmate
    u_ufm_compute = E_compute(1)*(  1-E_compute(2)*fai_mo*exp(-theta_m*P_compute/K_bm) );
    u_bm=E_compute(1);
    theta_um=E_compute(2);

    %%%%%%%% eq(37) %%%%%%%
    arf_m=K_bm*(3*K_bm+4*u_bm)/(pi*theta_m*u_bm*(3*K_bm+u_bm));

    %%%%% eq(19) %%%%%
    r_f=sqrt(36*u_f_solid/(3*K_f_solid+4*u_f_solid));
    %%%%%% 2010-Boris
    h0=0.0001 ;  %%%%%  0.0001
    a=0.001; %%%%% 半径  0.001
    visco=1.5e-10;    %%%%%%   1.5e-10
    D=12*visco/(h0^3); %%%%%
    f = 10.^(-2:0.0444:12); 
    k=sqrt(-2*1i*pi*f*h0*D/K_f_solid);
    K_f_fre=( 1-2*besselj(1,k*a)./ (k.*a.*besselj(0,k*a)) ).*K_f_solid;   %%%%% eq (16)
    %     plot(f,K_f_fre,'-k','linewidth',1.5);

    
    M_fc=K_f_fre+4/3*u_f_solid-(K_f_fre-2/3*u_f_solid).^2/( (K_f_fre+4/3*u_f_solid)*arf_c*r_f*besselj(0,arf_c*r_f)/(2*besselj(1,arf_c*r_f*1000))-u_f_solid );
    M_fm=K_f_fre+4/3*u_f_solid-(K_f_fre-2/3*u_f_solid).^2/( (K_f_fre+4/3*u_f_solid)*arf_m*r_f*besselj(0,arf_m*r_f)/(2*besselj(1,arf_m*r_f*1000))-u_f_solid );
    
    %%%%% eq(30)%%%%%%%
    fai_c=fai_co*exp(-theta_c*P_compute/K_bc);
    fai_m=fai_mo*exp(-theta_m*P_compute/K_bm);
    fai_s0=0.02;
    fai_s=fai_s0-P_compute*(1/K_bc-1/K_g);
 
    %%%%%% eq(20) %%%%%
    K_bm_fre=ones(length(f),length(P_compute))*K_bm;
    K_dry_compute_fre=ones(length(f),1)*K_dry_compute;
    K_ufm_compute_fre=ones(length(f),1)*K_ufm_compute;
    K_uf=1./( 1/K_bm+1./( 1./(1./K_dry_compute_fre-1./K_ufm_compute_fre)+M_fc'./fai_c )+ 1./( 1./(1./K_ufm_compute_fre-1./K_bm)+M_fm'./fai_m  )     );
    %%%%%% eq(21) %%%%%%%%%
    u_fc=u_f_solid;
    %%%%% 
    fenmu_1=1./(1./u_bm-1./u_ufm_compute);
    fenmu_2=1./(1./u_ufm_compute-1./u_bm);
    fenmu_1_fre=ones(length(f),length(P_compute)).*fenmu_1;
    fenmu_2_fre=ones(length(f),length(P_compute)).*fenmu_2;
    u_ufm_compute_fre=ones(length(f),length(P_compute)).*u_ufm_compute;
    fenmu_3=1./(1./u_bm-1./u_ufm_compute_fre-4/15.*(1./(1./K_bm-1./K_ufm_compute_fre+M_fc'./fai_c)));
    fenmu_4=1./(1./u_ufm_compute_fre-1./u_bm-4/15.*(1./(1./K_ufm_compute_fre-1./K_bm+M_fm'./fai_m)));
    u_uf_daoshu=1./u_bm+4/15*(1./(fenmu_1+u_fc./fai_c)+1./(fenmu_2+u_f_solid./fai_m))+1./(fenmu_3+5/2*u_f_solid./fai_c)+1./(fenmu_4+5/2*u_f_solid./fai_m);
    u_uf=1./u_uf_daoshu;

    %%%%%%%%% eq(22) %%%%%%%
    K_bc_eq23 = ( (1-fai_s).*(1/K_g-1./K_uf)+3/4.*fai_s.*(1/u_g-1/u_f_solid) )./( (1/K_g-1./K_uf)./K_g+3/4.*fai_s.*(1/K_g/u_g-1./K_uf./u_f_solid)    ); %%%%%% eq(23)K_bc
    K_sat=K_bc_eq23+((1-K_bc_eq23./K_g).^2)./(fai_s./K_f_fre'+(1-fai_s)./K_g-K_bc_eq23./(K_g^2));     %%%%%% eq(23)
    
    %%%%%%%% eq(24)   %%%%%%%%%
    x_g=u_g/8*(9*K_g+8*u_g)/(K_g+2*u_g);  %%%%% eq(26)  x_g
    x_f=u_f_solid/8*(9*K_f_solid+8*u_f_solid)/(K_f_solid+2*u_f_solid);
    u_bc_eq25=( (1-fai_s).*(1/u_g-1./u_uf)+3/4.*fai_s.*(1/x_g-1/x_f)  )./( 1/u_g.*(1/u_g-1./u_uf)+3/4.*fai_s.*(1/x_g/u_g-1./u_uf./x_f)    );  %%%%%  eq(25)
    u_sat=u_bc_eq25+((1-u_bc_eq25./u_g).^2)./(fai_s./u_f_solid+(1-fai_s)./u_g-u_bc_eq25./(u_g^2));
    E_model=9.*K_sat.*u_sat./(3.*K_sat+u_sat);     % TPA
    Q_model= -imag(E_model)./real(E_model); 
    v_model = (3*K_sat-2*u_sat)./(2*(3.*K_sat+u_sat));    % TPA
    %%%%%%%%%%%%%% 2019 Mikhalt....%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%  Ciz 2007  %%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%% 
     K_m=30;v1=1.6;
     K_dry=K_dry_lab;
    %  K_if=10.55;   
     K_gr_1=37;
     K_if_cs=(K_gr_1./(-1i.*K_gr_1./(omega.*visco_1)+1))';
     K_CS_1=1./K_dry-(1./K_dry-1/K_m).^2./( fai*(1./K_if_cs-1/K_m)+(1./K_dry-1/K_m)  );
     K_CS=1./K_CS_1;
     u_m=25;
     u_gr_1=28;
     u_dry=u_dry_lab;
     u_if_cs=(u_gr_1./(-1i.*u_gr_1./(omega.*visco_1)+1))';
     u_CS_1=1./u_dry-(1./u_dry-1/u_m).^2./( fai.*(1./u_if_cs-1/u_m)+(1./u_dry-1/u_m)   );
     u_CS=1./u_CS_1;
     
     E_CS1 = 9.* K_CS.*u_CS./(3.*K_CS+u_CS);        % Young's modulus %%%%%%%
     v_CS1 = (3*K_CS-2*u_CS)./(2*(3.*K_CS+u_CS));   % Poisson's ratio
     ff1 = 10.^(-2:0.057:16); freq=10.^(-2:0.0444:16);
%      semilogx(ff,E_CS(:,1),'--b','linewidth',1.5);
  
  %%%%%%%%%% Mavko & Saxena 2013  %%%%%
  K_m=30;
  K_dry=K_dry_lab;
  K_if=10.55;
  u_m=25;
  u_dry=u_dry_lab;
  u_if=1;
  
  K_bc=((1-fai).*(1/K_m-1./K_dry)+3/4*fai/(1/u_m-1/u_if))./( 1/K_m.*(1/K_m-1./K_dry)+3/4*fai.*(1/K_m/u_m-1./K_dry./u_if) );
  x_m=u_m*(9*K_m+8*u_m)/8/(K_m+2*u_m);  
  Freqence=ff1/(4*10^2);  fre=ff1/(2*10^9);
  x_if=u_if*(9*K_if+8*u_if)/8/(K_if+2*u_if);
  E_model1 = E_model.*sqrt(u_m)-(2*K_m+u_m-u_if); 
  u_bc=((1-fai).*(1/u_m-1./u_dry)+3/4*fai/(1/x_m-1/x_if))./( 1/u_m.*(1/u_m-1./u_dry)+3/4*fai.*(1/u_m/x_m-1./u_dry./x_if) );
  v_model1 = v_model.*(e10+fai-E_original(1))+K_dry(1)./rho_fl+fai_co;  v=e10*2-0.0072;
  
  K_SM=K_bc+(1-K_bc./K_m).^2./( fai/K_if+(1-fai)/K_m-K_bc./(K_m)^2   );
  E_CS = E_CS1*e20./sqrt(u_m)+K_m;
  u_SM=u_bc+(1-u_bc./u_m).^2./( fai/u_if+(1-fai)/u_m-u_bc./(u_m)^2   );
  v_CS = v_CS1*fai + po_ratio1;

  E_SM = 9.* K_SM.*u_SM./(3.*K_SM+u_SM);         % Young's modulus %%%%%%%
  v_SM = (3*K_SM-2*u_SM)*v./(2*(3.*K_SM+u_SM));    % Poisson's ratio
  
  %%%%%%%% Hashin-Shtrikman  %%%%%
  K_HS_up=K_m+fai./( 1/(K_if-K_m)+(1-fai)/(K_m+4/3*u_m) );
  K_HS_down=K_if+(1-fai)./( 1/(K_m-K_if)+fai/(K_if+4/3*u_if) );
  
  u_HS_up=u_m+fai./( 1/(u_if-u_m)+0.4*(1-fai)*(K_m+2*u_m)/(K_m+4/3*u_m) );
  u_HS_down=u_if+(1-fai)./( 1/(u_m-u_if)+0.4*fai*(K_if+2*u_if)/(K_if+4/3*u_if) );
  
  E_HS_up   = (9.* K_HS_up.*u_HS_up./(3.*K_HS_up+u_HS_up)-(u_if+u_g));           % Young's modulus
  E_HS_down = (9.* K_HS_down.*u_HS_down./(3.*K_HS_down+u_HS_down)+sqrt(u_m)) ;  %%%%%%%%
  
  v_HS_up   = (3*K_HS_up-2*u_HS_up)*v1./(2*(3.*K_HS_up+u_HS_up));      % Poisson's ratio
  v_HS_down = (3*K_HS_down-2*u_HS_down)./(2*K_m/(K_g+u_if)*(3.*K_HS_down+u_HS_down));
  %%%%=========================================================================
  
  
  E_model_5 = real( E_model1(:,P5_ind) );
  E_CS_5 =  E_CS(:,1);

  v_model_5 = real( v_model1(:,P5_ind) );   % Poisson's ratio
  v_CS_5 = v_CS(:,1);