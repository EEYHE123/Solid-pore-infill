function [E_model_fluid_5,v_model_fluid_5,Freq]=f2(K_g,u_g,rho_s,por,perm,P5_ind,K_f_fluid,rho_fluid,u_f_fluid,visco_fluid,ff,CC,Fontsize)
    K_g=K_g/10^9-15.6;   u_g=u_g/10^9-26.2;  fai=0.2356;   rho111=rho_s;  por11=por; k=perm;  omega=2*pi*ff;     
    visco_1=3.1;              % Viscosity of fluid in porous media 1: Pa*s
    rho_fl=770;               % Fluid Density 
    Kf_1=1.48*10^9;                
    %%%%%%%%%%%%%%%%%%%%%%% 液体正十八烷 %%%%%%%%
     rho_frame0=2944+50;    % 2944+50;       % Density of solid grains
     pore0=0.2356;      % 0.068;   %0.08932;   % Rock prosity
     K_ma0=20;               % Bulk modulus of solids grains
     visco_10=3.1;  %284*10^(-3);     % Viscocity of glycerin
     WR0=0.94*10^(-3);     % 0.4*10^(-2); 
     frequencyrange=10.^(-2:0.0444:16);      %%%% NO.=226

    freq=frequencyrange;
    omega=2*pi*frequencyrange;

    %%%%%%% 第一步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Calculate dry bulk and shear moduli at each confining pressure from P- and S velocities
    % Physical propertiers of the solid matrix
    rho_frame=rho_frame0;        % den_g is applied instead;  % Density of solid grain
    pore=pore0;                  % Rock porosity
    K_ma=K_ma0;                  % Bulk modulus of solid grains
    % M_ma=44;                   % Shear modulus of solid grains
    phi=pore;                    % Total porosity, assuming the porosity no change with pressures.
    % -------------------------------------------------------

    % For gas
    visco_2=15*10^(-5);   % 15*10^(-5);          % Viscosity of gas
    rho_f2=170; % 150;
    Kf_2=0.081*10^9;     % 0.081*10^9;

    den_wet=(1-phi)*rho_frame+phi*rho_fl;       % Saturated rock: Bulk density of porous medium
    den_dry=(1-phi)*rho_frame+phi*rho_f2;       % Dry rock: 
    K_g=20;    u_g=10;
    % den=2650;                             % Fluid-saturated rock density: 流体饱和岩石密度
    % --------------------------------------------------- ---------------------

    press=[5 10 20 30 40 50]*10^(-3);     % Pressure, GPa
        Vp_dry0 = [3776.216216 3960 4031.351351 4107.027027 4189.189189 4249.72973 4295.135135 4334.054054 ...
            4366.486486 4385.486486 4395.486486 4405.486486 4410.486486];
        Vs_dry0 = [2339.540743 2424.314198 2456.372926 2489.354867 2527.625899 2555.537219 2576.545588 ...
            2589.780649 2603.882543 2613.882543 2622.882543 2630.882543 2632.882543 ];
        Vp_dry = [Vp_dry0(2)+30 Vp_dry0(4) Vp_dry0(6) Vp_dry0(8) Vp_dry0(10) Vp_dry0(12)-10] ;
        Vs_dry = [Vs_dry0(2) Vs_dry0(4) Vs_dry0(6) Vs_dry0(8) Vs_dry0(10)-5 Vs_dry0(12)-18] ;
    
    Vp_wet0 = [4267.027027 4357.837838 4392.432432 4431.351351 4470.27027 4502.702703 ...
        4524.324324 4541.621622 4558.918919 4576.918919 4585.918919 4593.918919 4596.918919]; 
    Vs_wet0 = [2402.558802 2456.256644 2476.225518 2500.570841 2521.57921 2539.997651 ...
        2553.232712 2565.604463 2575.389811 2582.389811 2589.389811 2595.389811 2598.389811];
    Vp_wet = [Vp_wet0(2)+50 Vp_wet0(4) Vp_wet0(6) Vp_wet0(8) Vp_wet0(10)-20 Vp_wet0(12)-20] ;
    Vs_wet = [Vs_wet0(2) Vs_wet0(4) Vs_wet0(6) Vs_wet0(8) Vs_wet0(10) Vs_wet0(12)] ;    
    
    Vp_gly0 = [4366.486486 4444.324324 4474.594595 4502.702703 4537.297297 4558.918919 ...
        4578.378378 4591.351351 4604.324324 4619.324324 4628.324324 4634.324324 4639.324324];
    Vs_gly0 = [2450.904126 2487.33578 2499.538394 2513.524005 2531.072089 2539.130818 ...
        2548.916165 2555.248275 2560.713552 2565.713552 2569.713552 2574.713552 2576.713552];
    Vp_gly = [Vp_gly0(2)+10 Vp_gly0(4) Vp_gly0(6) Vp_gly0(8) Vp_gly0(10)-20 Vp_gly0(10)];
    Vs_gly = [Vs_gly0(2) Vs_gly0(4) Vs_gly0(6) Vs_gly0(8) Vs_gly0(10) Vs_gly0(12)];
    % --------------------------------------------
    
    [K_dry0,U_dry0] = v2ku(Vp_dry0,Vs_dry0,den_dry);       % Bulk and shear modulus: dry rock
    [K_wet0,U_wet0] = v2ku(Vp_wet0,Vs_wet0,den_wet);       % Bulk and shear modulus: Brine saturated rock; not applied
    
    Kd_p0 = K_dry0/10^9;
    ud_p0 = U_dry0/10^9;
    
    Kd_p=[Kd_p0(2) Kd_p0(4) Kd_p0(6) Kd_p0(8) Kd_p0(10) Kd_p0(12)];    % Dry bulk modulus
    ud_p=[ud_p0(2) ud_p0(4) ud_p0(6) ud_p0(8) ud_p0(10) ud_p0(12)];    % Dry shear modulus
    % ---------------------------------------------------------------------
    % -------------------------------------------------------------------------

    y      = 1./Kd_p;                          % Dry compressibislity: C=1/Kdi:压缩性 %1/Gpa
    C_ud_p = 1./ud_p;                          % Dry compressibislity

    press_1=press*10^3;
    xx0 = press(1)*10^3:0.2:press(end)*10^3;   % Pressure
    xx  = xx0*10^(-3);                         % pa
    %%% ==========================================================


    %%%%%%% 第二步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%    Least-square fitting to calculate four parameters of compliant pore
    Kg=K_ma;                 % Bulk modulus of solid grain, Gpa
    Kg1=Kg*10^9;
    Cg=1/Kg;                 % Grain compressibility (颗粒压缩性): Eq(11)

    % -------------------------------------------
    Vpg=5;   %5;                        % P-wave velocity of shaley sandstone: km/s
    Fc=(5.59-Vpg)/2.18;           % Clay content, Eq(21); 黏土含量
    Vsg=3.52-1.89*Fc;             % S-wave velocity of shaley sandstone Eq(22): km/s

    den_g=Kg/(Vpg^2-4*Vsg^2/3);   % Density of solid grain, kg/m^3
    ug=den_g*Vsg^2;               % Shear modulus of solid grain, Gpa
    ug1=ug*10^9; 
    Mg=1/ug;
    KF=K_f_fluid;
    % -------------------------------------------------------------------------

    %%%%  Eq(12), Bulk modulus compressibility %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    fun = @(A)A(1)*(1-A(2)*(A(1)-Cg)*press+A(3)*A(4)*exp(-A(3)*A(1)*press)) - 1./Kd_p;   % Dry compressibislity  
        t0=[30 1 3195 0.1];          % Data from Lab, M9
    %     t0=[150 1 1195 0.01];                  % Initial value is the key
    options = optimoptions(@lsqnonlin,'Algorithm','trust-region-reflective');
    t4 = lsqnonlin(fun,t0,[],[],options);        % Four parmaters calculated

    CdP1 = t4(1)*(1-t4(2)*(t4(1)-Cg)*xx+t4(3)*t4(4)*exp(-t4(3)*t4(1)*xx));     % Dry elastic compressibility (Eq12):干骨架压缩性 C_K

    Cds0=t4(1);          % Drained compressibility, below Eq(9)
    theta_s=t4(2);       % Pressure sensitivity coefficient for stiff potosity
    theta_c=t4(3);       % Pressure sensitivity coefficient for compliant potosity
    phi_co=t4(4);        % Compliant potosity in the unstressed rock, at 0 MPa

    % -----------------------------------------
    %%% Eq(12), Shear modulus compressibility %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    fun1 = @(E)E(1)*(1-E(2)*(E(1)-Mg)*press+E(3)*E(4)*exp(-E(3)*E(1)*press))-1./ud_p;
        g0=[0.05 1 3995 0.5];            % Initial value is the key

    options = optimoptions(@lsqnonlin,'Algorithm','trust-region-reflective');
    g4=lsqnonlin(fun1,g0,[],[],options);

    yy3 = g4(1)*(1-g4(2)*(g4(1)-Mg)*xx+g4(3)*g4(4)*exp(-g4(3)*g4(1)*xx));      % Dry elastic compressibility (Eq12): 干骨架压缩性 C_u
    rho_m=rho_fluid;
%%%%%%% 第二步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% 第三步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Kh=1/Cds0;                    % Eq(9), Dry bulk modulus in the high-pressure-limit (when all compliant pore is closes), Gpa

    den  = (1-phi)*den_g*10^3+phi*rho_fl;       % Bulk density of porous medium

    % -----------------------------------------------------

    sub=Kh/Kg;
    syms phi_b1; 
    % phi_h=solve( (1-phi_h)^(3/(1-phi_h))-sub,'phi_h');   
    phi_b1 = solve( (1-phi_b1)^(3/(1-phi_b1))- sub );         % 2013_GJI-Kong_Effect_of_fracture (Eq36)
    solution_phi_h=double(phi_b1); 
    uh = ug*(1-solution_phi_h)^(3/(1-solution_phi_h));     % 2013_GJI-Kong_Effect_of_fracture (Eq36), Gpa
    uf=u_f_fluid;
    alpha_c = Kh*(3*Kh+4*uh)/(pi*uh*theta_c)/(3*Kh+uh);    % Characteristic aspect ratio of compliant pore (Eq13): 软孔特征纵横比 
    % ==========================================================================
    % ===================================================================================
    %%% Calculating aspect ratio distribution of compliant pores
    ud_p1=ud_p.*1e9;        % Dry bulk modulus, pa
    Kd_p1=Kd_p.*1e9;        % Dry shear modulus,
    po_ratio1 = (3*Kd_p1-2*ud_p1)./2/(3*Kd_p1+ud_p1);      % Poisson's ratio -- 岩石物理手册, page28

    p=press*10^3*10^6;              % pa
    dp=0.2*10^6;vis=visco_fluid;
    pp=0:dp:p(end);

    %%% espilon, 岩石中所有未闭合软孔隙的累积裂缝密度
    e1=(Kd_p1(end)./Kd_p1-1)*9*(1-2*po_ratio1(end))/16/(1-po_ratio1(end)^2);                % Crack density from the bulk modulus, in Eq.(5) of 2015_CG
    e2=(ud_p1(end)./ud_p1-1)*45*(2-po_ratio1(end))/32/(1-po_ratio1(end))/(5-po_ratio1(end));  % Crack density from the shear modulus, in Eq.(5) of 2015_CG 

    z1=log(e1(1:end-1));         %%% Fitting the curves   
    z2=log(e2(1:end-1));

    c1=polyfit(p(1:end-1),z1,1);
    c2=polyfit(p(1:end-1),z2,1);

    ie1=exp(c1(1)*pp+c1(2));             %%% 不同压力下的裂缝密度
    ie2=exp(c2(1)*pp+c2(2));             % Fitting crack density, Eq.(7) of 2015_CG
    e10=exp(c1(2));
    e20=exp(c2(2));                      % 零压力下初始裂隙密度

    ie=(ie1+ie2)/2;                      %%% Mean of bulk and shear moduli

    iei=[0 ie(1:end-1)-ie(2:end)];       % 各个纵横比(or different pressure)对应的裂隙密度
    iek=[0 ie1(1:end-1)-ie1(2:end)];     % 各个纵横比对应的裂隙密度
    ieu=[0 ie1(1:end-1)-ie1(2:end)];

    % -------------------------------------------------------------------------
    % Kd_p2 & ud_p2: the dry effective modulus; %%% 整个压力范围内，计算拟合后的干骨架模量
    Kd_p2 = Kd_p1(end)./(1+16*(1-po_ratio1(end)^2)*ie1/9/(1-2*po_ratio1(end)));
    ud_p2 = ud_p1(end)./(1+32*(1-po_ratio1(end))*(5-po_ratio1(end))*ie2/45/(2-po_ratio1(end)));
    %%% Kd_p1(end):   K_stiff of Eq.(5) in 2015_CG
    %%% ud_p1(end):   The Poisson's ratio of the background matrix with only hard pores

    lamda_st2=Kd_p2-2*ud_p2/3;
    E2=3*Kd_p2.*ud_p2./(lamda_st2+ud_p2);                 % Not used!
    po_ratio2=0.5*lamda_st2./(lamda_st2+ud_p2);           % The Poisson's ratio

    lamda_st3=Kd_p1(end)-2*ud_p1(end)/3;                     % High-freq limit；%%% 计算最大压力下的模量，软孔隙接近完全闭合
    E3=3*Kd_p1(end).*ud_p1(end)./(lamda_st3+ud_p1(end));     % Young's modulus
    po_ratio3=0.5*lamda_st3./(lamda_st3+ud_p1(end));

    alphai=4*(1-po_ratio3.^2).*pp./E3/pi;                    % Eq.(10) in 2015_CG, Eq.(12) in 2018_JGE
                                                             %%% 各个纵横比随压力的变化

    %%% Aspect ratio Variations with pressure: Eq.(13) in 2018_JGE
    alphap=zeros(length(pp),length(pp));         %% Aspect ratio,所有软孔隙的纵横比值与压力的关系：
    for ix=1:length(pp)
        if ( ix==1 )
            alphap(:,ix)=alphai-4*(1-po_ratio3^2)*0*dp/3/pi/Kd_p1(end)/(1-2*po_ratio3);        
        elseif ( ix>1 )
            alphap(:,ix)=alphap(:,ix-1)-4*(1-po_ratio3^2)*dp/3/pi/Kd_p1(end)/(1-2*po_ratio3);
        end
    end

    iei1=iei'*ones(1,length(pp));        % Crack density, 累积裂隙密度分布图算法二
    iek1=iek'*ones(1,length(pp));
    ieu1=ieu'*ones(1,length(pp));
    phyi=4*pi*alphap.*iei1/3;            % Line-15 in P-3394 in 2015_CG, Eq.(9) in 2018_JGE
                                         % Porosity of soft pores

    % -------------------------------------------------------------------------
    %%%%%% Remove the negative values                                    
    nn1=1;     nn2=1;              % 寻找每一压力下软孔隙度和纵横比非零值的起点
    mn=zeros(1,length(pp));
    for np=1:length(pp)
          for n=1:length(pp)
              if phyi(n,np)<=1e-10
                  nn1=n+1;
              end
              if alphap(n,np)<=1e-10
                  nn2=n+1;
              end
          end
          if nn1>length(pp)&&nn2>length(pp)
              nn1=length(pp);
              nn2=length(pp);
          end
          mn(np)=max([nn1 nn2]);
    end 

    for np=1:length(pp)
    %     iei1(n,mn(np))=0;
        for n=mn(np):length(pp)                
            iei1(n,np)=iei1(n-1,np)+iei1(n,np);
            iek1(n,np)=iek1(n-1,np)+iek1(n,np);
            ieu1(n,np)=ieu1(n-1,np)+ieu1(n,np);
        end
    end
    % -------------------------------------------------------------------------

    phi_cp = phi_co*exp(-theta_c*Cds0*xx);      % Compliant porosity, Eq(11)
        %%%%  SC  ======================================================
            WR=WR0;           % WR=0.44*10^-9;  影响第一个衰减峰峰值频率，反比
            Sw=1;
            Sc0=WR*Sw*phi*phi_cp.^(-1);  % Eq6 -- 2018-李东庆_软空隙含水饱和度
            Sc=Sc0;               %  Method 1
     
        %%%%%%%  ======================================================

    nc=26;
    for np=nc:length(pp)
        nn=mn(np);

        Kdry=Kd_p2(np);
        Kmf_alpha_c=0;
        if ( nn<=length(po_ratio2) )
            for ix=nn:length(po_ratio2)
                faic=phyi(ix,np);
                alpha=alphap(ix,np);

                Khi(ix)=Kd_p1(end)./(1+16*(1-po_ratio1(end)^2)*(ie1(np)-iek(ix))/9/(1-2*po_ratio1(end)));             %

                [Kmf_sp0,Kf_f0] = K_MF_2( Khi(ix),Kdry,omega,visco_1,visco_2,faic,alpha,Kg1,Kf_1,Kf_2,Sc(np-25) );    % Bulk modulus

                z=find(~isnan(Kmf_sp0));
                if ( z(end)<length(freq) )
                     Kmf_sp0(z(end)+1:end) = Kmf_sp0(z(end));    %%% 排除NAN值
                end
                Kmf_alpha_c = Kmf_alpha_c + Kmf_sp0;
            end
        end

        Kmf_alpha_c1(:,np-(nc-1)) = Kmf_alpha_c;
    end

    %%%%% ---------------------------------------------------------------------
    %%% GJI applied 
    kki=121;

 
    %%%%%%% 第三步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% 第四步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Ke=23;%GPa
    K2=0.04;   % 0.03;        % 2.25;
    u2=0;
    %%% 岩石物理手册, page118
    pmi = (Kg1+4*ug1/3)/(K2+4*ug1/3);        % 包含物形状：球体
    Ke1 = Kg1+phi*(K2-Kg1)*pmi;              % 岩石物理手册, page118, pa
    Ke=Ke1*10^(-9);
    Ce=1/Ke;
    %%%%%%% 第四步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% 第五步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Cds_p  = Cds0*(1-theta_s*(Cds0-Cg)*press);         % Eq(12)-指数项, From Lab data
    Cds_p1 = Cds0*(1-theta_s*(Cds0-Cg)*xx);            % Eq(12)-指数项, Theoretical prediction
    %%%%%%% 第五步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% 第六步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%    Least-square fitting to calculate two parameters of intermediate pore
    ff=@(B)Ce*(1+B(1)*B(2)*exp(-B(1)*Ce*press)) - Cds_p;             % Eq(19)
        d0=[0.0009 0.1];        % index_case = 1;    % Applied 

    options = optimoptions(@lsqnonlin,'Algorithm','trust-region-reflective');
    d1=lsqnonlin(ff,d0,[],[],options);
    theta_m=-d1(1);       % Porosity of the intermediate pore.
    % theta_m=0.8;       % Porosity of the intermediate pore.
    phi_mo=d1(2);        % Intermediate porosity at zero confining stress.

    C_sp = Ce*(1+d1(1)*d1(2)*exp(-d1(1)*Ce*xx));        % Eq(19), 只有硬孔时岩石压缩性
    %%%%%%% 第六步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% 第七步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%  Intermediate pore, similar to step 3 for the compliant porosity
    Freq=freq./(9*10^3);
    sub1=Ke/Kg;
    syms phi_b2; 
    % phi_e=solve((1-phi_e)^(3/(1-phi_e))==sub1,'phi_e');   
    phi_b2=solve( (1-phi_b2)^(3/(1-phi_b2))-sub1 );             % 2013_GJI-Kong_Effect_of_fracture (Eq36)
    solution_phi_e=double(phi_b2);
    ue = ug*(1-solution_phi_e)^(3/(1-solution_phi_e));        % 2013_GJI-Kong_Effect_of_fracture (Eq36)

    alpha_m = Ke*(3*Ke+4*ue)/(pi*ue*theta_m)/(3*Ke+ue);       % Eq30, 中间孔特征纵横比
    %%%%%%% 第七步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%%%%% 第八步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    fc = 4*uh*(3*Kh+uh)*alpha_c^3/3/visco_1/(3*Kh+4*uh)*10^9;         % Eq(31)--特征频率: stiff & compliant pores
    clc;
    fprintf('\n================================================================\n');
    fprintf('Characteristic frequency Fc of the squirt dispersion is %f Hz',fc);
    fprintf('\n================================================================\n');

    %%% 硬孔和软孔之间作用的骨架模量-- stiff & compliant pores
    Kds_p=1./Cds_p1;                           % From 第五步, Eq(27)
    Kds_p1=ones(length(omega),1)*Kds_p*10^9;   % Pa

    yy2=1./CdP1;                                % 干骨架体积模量，拟合出来的
    Kd_p_1=ones(length(omega),1)*yy2*10^9;      % 矩阵增加维度 %Pa %Kd_p

    yy4=1./yy3;                                 % 干骨架剪切模量，拟合出来的
    ud_p_1=ones(length(omega),1)*yy4*10^9;

    %%% Flow between stiff & compliant pores
    Kmf = 1./( (1./Kds_p1) + (1./((1./((1./Kd_p_1)-(1./Kds_p1)))+(3*1i.*(omega'*visco_1*(Sc.*phi_cp.^-1))/8/alpha_c^2))) );    % Eq(27)--改进骨架的体积模量
    umf = 1./( (1./ud_p_1)-(4.*((1./Kd_p_1)-(1./Kmf))/15) );                                                                 % Eq(4) --改进骨架剪切模量

    %%% 硬孔和软孔之间作用的骨架模量 -- Considering aspect ratio distribution
    Kmf_alph = 1./( 1./Kds_p1+Kmf_alpha_c1 );                           % Eq(27)--改进骨架的体积模量
    umf_alph = 1./((1./ud_p_1)-(4.*((1./Kd_p_1)-(1./Kmf_alph))/15));    % Eq(4)  --改进骨架剪切模量
    %%%%%%% 第八步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



    %%%%%%% 第九步 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% 中间孔和等孔之间作用的骨架模量--intermediate & equant pores
    phi_m=phi_mo*exp(-theta_m*Ce*xx);          % Intermediate porosity, Eq(17)
    Ke1=Ke*1e9;

    Kmf1 = 1./( (1/Ke1) + 1./(1./((1./Kds_p1)-(1/Ke1))+(3*1i*omega'*visco_1*phi_m.^-1/8/alpha_m^2)) );   % Eq(28)--改进骨架的体积模量
    umf1 = 1./((1./ud_p_1)-(4.*((1./Kd_p_1)-(1./Kmf1))/15));                                            % Eq(4) --改进骨架剪切模量

    E_model_fluid1=1./(9.*Kmf1.*umf1 ./(3.*Kmf1+umf1 )).*1e+12;
    E_model_fluid=E_model_fluid1./(Vpg+sub1)+(Vpg-e20)*Kg*e10; 
    v_model_fluid1 = (3*Kmf1-2*umf1)./(2*(3.*Kmf1+umf1));    % TPA
    v_model_fluid=(Fc-K2-phi_mo/u_g-real(v_model_fluid1*K2*u_g))*(Cg*(kki+Vpg)/u_g)+K2+Vsg/u_g^2;
    % ----------------------------------------------------------------------------
      E_model_fluid_5  = E_model_fluid(:,2);
      save E_model_fluid_5;
      v_model_fluid_5  =  v_model_fluid(:,P5_ind) ;
      save v_model_fluid_5;
      save Freq;