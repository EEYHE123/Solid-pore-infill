
Version: 2023-10-26

Step 1: Run the code "triple_porosity_fluid.m" to calculate the Young's modulus and Poisson's ratio for fluid-saturated rock at differential pressure 5 MPa, 
the output files were saved as "E_model_fluid_5.mat" & "v_model_fluid_5.mat"; 

Step 2: Run the code "triple_porosity_solid_fluid.m" to calculate the Young's modulus and Poisson's ratio for solid-saturated rock at differential pressure 5 MPa, 
and then plot all curves in Figure 12(a) and 12(c) by using the saved data in "E_model_fluid_5.mat" & "v_model_fluid_5.mat".