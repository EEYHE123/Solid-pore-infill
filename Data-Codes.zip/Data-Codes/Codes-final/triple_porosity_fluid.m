%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     A triple porosity scheme for fluid/solid substitution: theory and experiment   %
%                                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% DS-1 %%%%%%%
% Version:  2022-08-11, 08-13, 2023-07-02, 2023-10-16
%%%%%%%%%%%%%%%%%%%%%% freq+aspect ratio %%%%%%% 
clc;   clear;
CC=colormap(jet(6));         % Color, open a figure
Fontsize=13;  
Fontsize1=13;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%% for fluid    %% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

filename='Ds-1-shibawan';
f_measure=xlsread(filename,1,'A3:A39'); 

  % ------------- Dry -----------------------------------------------------
  load('./Data/E_dry.mat');        % Young's modulus
  load('./Data/QE_dry.mat');       % Young's attenuation
  load('./Data/pos_dry.mat');      % Poisson's ratio
  
  E1_rbw_dry = E_dry_sm(:,1);    % 1 MPa
  E5_rbw_dry = E_dry_sm(:,2);    % 5 MPa applied
  E10_rbw_dry = E_dry_sm(:,3);   % 10 MPa applied
  E15_rbw_dry = E_dry_sm(:,4);   % 15 MPa
  E20_rbw_dry = E_dry_sm(:,5);   % 20 MPa
  
  QE1_rbw_dry = QE2_dry_sm1(:,1);    % 1 MPa
  QE5_rbw_dry = QE2_dry_sm1(:,2);    % 5 MPa applied
  QE10_rbw_dry = QE2_dry_sm1(:,3);   % 10 MPa applied
  QE15_rbw_dry = QE2_dry_sm1(:,4);   % 15 MPa
  QE20_rbw_dry = QE2_dry_sm1(:,5);   % 20 MPa
  
  v1_rbw_dry  = v_sm(:,1);       % 1 MPa
  v5_rbw_dry  = v_sm(:,2);       % 5 MPa applied
  v10_rbw_dry = v_sm(:,3);       % 10 MPa applied
  v15_rbw_dry = v_sm(:,4);       % 15 MPa
  v20_rbw_dry = v_sm(:,5);       % 20 MPa
  
  % --------- solid -------------------------------------------------------
  load('./Data/E_23.mat');
  load('./Data/QE_23.mat');
  load('./Data/pos_23.mat');      % Poisson's ratio
  
  E1_23rbw = E_rbw_23(:,1);    % 1 MPa
  E5_23rbw = E_rbw_23(:,2);    % 5 MPa applied
  E10_23rbw = E_rbw_23(:,3);   % 10 MPa applied
  E15_23rbw = E_rbw_23(:,4);   % 15 MPa
  E20_23rbw = E_rbw_23(:,5);   % 20 MPa
  
  QE1_23rbw = QE_rbw_23(:,1);    % 1 MPa
  QE5_23rbw = QE_rbw_23(:,2);    % 5 MPa applied
  QE10_23rbw = QE_rbw_23(:,3);   % 10 MPa applied
  QE15_23rbw = QE_rbw_23(:,4);   % 15 MPa
  QE20_23rbw = QE_rbw_23(:,5);   % 20 MPa

  v1_rbw_23  = v_sm1(:,1);       % 1 MPa
  v5_rbw_23  = v_sm1(:,2);       % 5 MPa applied
  v10_rbw_23 = v_sm1(:,3);       % 10 MPa applied
  v15_rbw_23 = v_sm1(:,4);       % 15 MPa
  v20_rbw_23 = v_sm1(:,5);       % 20 MPa
  
  % -------------- fluid --------------------------------------------------
  load('./Data/E_30.mat');
  load('./Data/QE_30.mat');
  load('./Data/pos_30.mat');      % Poisson's ratio
  
  E1_30rbw = E_rbw_30(:,1);    % 1 MPa
  E5_30rbw = E_rbw_30(:,2);    % 5 MPa applied
  E10_30rbw = E_rbw_30(:,3);   % 10 MPa applied
  E15_30rbw = E_rbw_30(:,4);   % 15 MPa
  E20_30rbw = E_rbw_30(:,5);   % 20 MPa
  
  QE1_30rbw = QE_rbw_30(:,1);    % 1 MPa
  QE5_30rbw = QE_rbw_30(:,2);    % 5 MPa applied
  QE10_30rbw = QE_rbw_30(:,3);   % 10 MPa applied
  QE15_30rbw = QE_rbw_30(:,4);   % 15 MPa
  QE20_30rbw = QE_rbw_30(:,5);   % 20 MPa
  
  v1_rbw_30  = v_sm30(:,1);       % 1 MPa
  v5_rbw_30  = v_sm30(:,2);       % 5 MPa applied
  v10_rbw_30 = v_sm30(:,3);       % 10 MPa applied
  v15_rbw_30 = v_sm30(:,4);       % 15 MPa
  v20_rbw_30 = v_sm30(:,5);       % 20 MPa  
%%%%=========================================================================

K_dry_lab=xlsread(filename,7,'C83:H83'); 
u_dry_lab=xlsread(filename,7,'C84:H84'); 

K_g = 35.6e9;
u_g = 36.2e9;
rho_s=2638;
por=0.201;
perm=272.1e-15;         %%%颗粒模量

P_lab=[5 10 20 30 40 50].*1e-3;              %%% pressure  Lab；   乘负三次方是与模量单位Gpa保持一致
P_compute= P_lab(1):(1*1e-4):P_lab(end);       %%%pressure 拟合

P5_ind = 1;          % Pressure, MPa
%-----------------------------------------

K_f_fluid=3.87;
u_f_fluid=1.46;
rho_fluid=778.2;
visco_fluid=3.3e-3;

ff = 10.^(-2:0.057:16);   % Frequency

visco_10=5*10^(-3);
WR0=0.94*10^(-3); 
visco_2=1*10^(-5);   % 15*10^(-5);   % Viscosity of gas

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[E_model_fluid_5,v_model_fluid_5,Freq]=f2(K_g,u_g,rho_s,por,perm,P5_ind,K_f_fluid,rho_fluid,u_f_fluid,visco_fluid,ff,CC,Fontsize);
  % -----------------------------------------------------------------------
  %%% GJI applied, v
  scrsz = get(0,'ScreenSize');      %%  5 MPa
  figure('Position',[1 scrsz(4) scrsz(4)*0.55 scrsz(4)*0.36]);
      h8=semilogx(f_measure(1:2:36),v5_rbw_30(1:2:end),'sk','linewidth',1);  hold on  % Fluid
      h9=semilogx(Freq,   v_model_fluid_5,'-m','linewidth',1.);             % TPA: triple pore       
      
      set(gca,'xtick',[10^-2,10^-1,1,10,10^2,10^3,10^4,10^5,10^6],'Fontsize',Fontsize1);
      set(gca,'ytick',[0.1,0.2,0.3,0.4],'Fontsize',Fontsize1);
      xlabel('Frequency (Hz)','Fontsize',Fontsize1);
      ylabel('Poisson'' ratio {\it\nu}','Fontsize',Fontsize1); 
      xlim([10^-1 10^5]);      ylim([0.05 0.3]);
      box on;   grid on;   grid minor;      
      hh1=legend('Liquid','TPA (liquid)');  % ,'Gassmann');
      set(hh1 ,'FontName','Times New Roman','Fontsize',Fontsize1);
    % ------------------------------------------------ 
    %%% ====================================================================  
    %%% GJI applied, E
     scrsz = get(0,'ScreenSize');      %%  5 MPa
     figure('Position',[1 scrsz(4) scrsz(4)*0.55 scrsz(4)*0.36]);
        h8=semilogx(f_measure(1:2:36),E5_30rbw(1:2:end),'sk','linewidth',1); hold on  % Fluid
        h9=semilogx(Freq,   E_model_fluid_5,'-m',  'linewidth',1.0);        % TPR: triple pore  
    %     h9=plot([1e-2,1e+6],[E_SM(1)-1,E_SM(1)-1],'-g','linewidth',1.);         % Gassmann

        set(gca,'xtick',[10^-2,10^-1,1,10,10^2,10^3,10^4,10^5,10^6],'Fontsize',Fontsize1);
        set(gca,'ytick',[10,20,30,40,50],'Fontsize',Fontsize1);
        xlabel('Frequency (Hz)','Fontsize',Fontsize1);
        ylabel('Young''s modulus {\itE} (GPa)','Fontsize',Fontsize1);
        xlim([10^-1 10^5]);     %%%%%% 30℃
        ylim([10 45]);
        box on;   grid on;   grid minor;
        hh1=legend('Liquid','TPA (liquid)');  % ,'Gassmann');
        set(hh1 ,'FontName','Times New Roman','Fontsize',Fontsize1);
      % -----------------------------------------
%%% =========================================================================