function [Kmf,Kf_f1] = K_MF_2(Kh1,Kdry,omegia,Viscosity1,Viscosity2,faic,alpha,Kg,Kf1,Kf2,Sc)
%UNTITLED10 Summary of this function goes here
%   Detailed explanation goes here
%  kg is gas

Ka1=1./alpha*(-3i*omegia*Viscosity1/Kf1).^(1/2);
Kf_1=(1-2*besselj(1,Ka1)./(Ka1.*besselj(0,Ka1)))*Kf1;
Kf_f1=Kf_1;

Ka2=1./alpha*(-3i*omegia*Viscosity2/Kf2).^(1/2);
Kf_2=(1-2*besselj(1,Ka2)./(Ka2.*besselj(0,Ka2)))*Kf2;
Kf_f2=Kf_2;
              nan_loc1=find(isnan(Kf_1)==1);
              if isempty(nan_loc1)==0
                  if nan_loc1(1)==1
                      Kf_1(find(isnan(Kf_1)==1)) =Kf1;
                  elseif nan_loc1(1)>1
                      Kf_1(find(isnan(Kf_1)==1)) =Kf_1(nan_loc1(1)-1);
                  end
              end
              nan_loc2=find(isnan(Kf_2)==1);
              if isempty(nan_loc2)==0
                  if nan_loc2(1)==1
                      Kf_2(find(isnan(Kf_2)==1)) =Kf2;
                  elseif nan_loc2(1)>1
                      Kf_2(find(isnan(Kf_2)==1)) =Kf_2(nan_loc2(1)-1);
                  end
              end
Kmf=1./(1./(1/Kdry-1./Kh1)+Sc./(1./Kf_1-1/Kg)/faic+(1-Sc)./(1./Kf_2-1/Kg)/faic);

% Kmf=1./Kh+1./(1./(1./Kh1-1./Kh)+3*1i*omegia*Viscosity./8/faic/alpha/alpha);

end

